.. _security:

.. mdinclude:: ../../../SECURITY.md

.. vi: textwidth=78
